$(() => {
    $('ul > li:nth-child(3n+1)').addClass('add-color');
});