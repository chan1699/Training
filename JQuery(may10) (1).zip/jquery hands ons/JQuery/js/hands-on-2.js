$(() => {
    $('li > a').nextAll().addClass('afterlink');
});